import { getSongs, optimizeImage } from "@/lib/songs";
import SongBrowser from "./SongBrowser";

// প্রতি ৬০ সেকেন্ডে পেজ নতুন করে তৈরি হয়, তাই নতুন গান দ্রুত দেখা যায়
export const revalidate = 60;

export default async function Home() {
  const raw = await getSongs();
  const songs = raw.map((s) => ({ ...s, coverUrl: optimizeImage(s.coverUrl, 400) }));

  return (
    <>
      <h1>সব গান</h1>
      <p className="sub">নতুন গান শুনুন ও খুঁজে নিন</p>
      <SongBrowser songs={songs} />
    </>
  );
}
