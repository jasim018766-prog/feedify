"use client";

import { useEffect, useState } from "react";
import {
  onAuthStateChanged,
  signInWithEmailAndPassword,
  signOut,
} from "firebase/auth";
import {
  addDoc,
  collection,
  deleteDoc,
  doc,
  getDocs,
  orderBy,
  query,
  serverTimestamp,
} from "firebase/firestore";
import { db, getAuthClient } from "@/lib/firebase";

const CLOUD = process.env.NEXT_PUBLIC_CLOUDINARY_CLOUD_NAME;
const PRESET = process.env.NEXT_PUBLIC_CLOUDINARY_UPLOAD_PRESET;

function uploadToCloudinary(file, onProgress) {
  return new Promise((resolve, reject) => {
    const fd = new FormData();
    fd.append("file", file);
    fd.append("upload_preset", PRESET);
    const xhr = new XMLHttpRequest();
    xhr.open("POST", `https://api.cloudinary.com/v1_1/${CLOUD}/auto/upload`);
    xhr.upload.onprogress = (e) => {
      if (e.lengthComputable) onProgress(Math.round((e.loaded / e.total) * 100));
    };
    xhr.onload = () => {
      try {
        const res = JSON.parse(xhr.responseText);
        if (xhr.status >= 200 && xhr.status < 300) resolve(res.secure_url);
        else reject(new Error(res.error?.message || "Cloudinary আপলোড ব্যর্থ"));
      } catch {
        reject(new Error("Cloudinary আপলোড ব্যর্থ"));
      }
    };
    xhr.onerror = () => reject(new Error("নেটওয়ার্ক সমস্যা"));
    xhr.send(fd);
  });
}

export default function Admin() {
  const [user, setUser] = useState(undefined);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [authErr, setAuthErr] = useState("");

  const [title, setTitle] = useState("");
  const [artist, setArtist] = useState("");
  const [description, setDescription] = useState("");
  const [audio, setAudio] = useState(null);
  const [cover, setCover] = useState(null);
  const [progress, setProgress] = useState(0);
  const [busy, setBusy] = useState(false);
  const [status, setStatus] = useState(null);
  const [songs, setSongs] = useState([]);

  useEffect(() => onAuthStateChanged(getAuthClient(), setUser), []);

  async function loadSongs() {
    const snap = await getDocs(query(collection(db, "songs"), orderBy("createdAt", "desc")));
    setSongs(snap.docs.map((d) => ({ id: d.id, ...d.data() })));
  }

  useEffect(() => {
    if (user) loadSongs().catch(() => {});
  }, [user]);

  async function login(e) {
    e.preventDefault();
    setAuthErr("");
    try {
      await signInWithEmailAndPassword(getAuthClient(), email, password);
    } catch {
      setAuthErr("ইমেইল বা পাসওয়ার্ড ভুল।");
    }
  }

  async function submit(e) {
    e.preventDefault();
    if (!audio) return setStatus({ type: "err", text: "অডিও ফাইল দিন।" });
    if (!CLOUD || !PRESET)
      return setStatus({ type: "err", text: "Cloudinary env ভ্যালু সেট করা নেই।" });

    setBusy(true);
    setStatus(null);
    try {
      setProgress(0);
      const audioUrl = await uploadToCloudinary(audio, setProgress);
      let coverUrl = "";
      if (cover) {
        setProgress(0);
        coverUrl = await uploadToCloudinary(cover, setProgress);
      }
      await addDoc(collection(db, "songs"), {
        title: title.trim(),
        artist: artist.trim(),
        description: description.trim(),
        audioUrl,
        coverUrl,
        createdAt: serverTimestamp(),
      });
      setStatus({ type: "ok", text: "গান যোগ হয়েছে। সাইটে আসতে ১ মিনিট লাগতে পারে।" });
      setTitle(""); setArtist(""); setDescription("");
      setAudio(null); setCover(null); setProgress(0);
      e.target.reset();
      loadSongs();
    } catch (err) {
      setStatus({ type: "err", text: err.message || "কিছু একটা ভুল হয়েছে।" });
    } finally {
      setBusy(false);
    }
  }

  async function remove(id) {
    if (!confirm("এই গানটি মুছে ফেলবেন?")) return;
    await deleteDoc(doc(db, "songs", id));
    loadSongs();
  }

  if (user === undefined) return <p className="sub">লোড হচ্ছে...</p>;

  if (!user)
    return (
      <>
        <h1>অ্যাডমিন লগইন</h1>
        <p className="sub">&nbsp;</p>
        <form className="form" onSubmit={login}>
          <label>ইমেইল
            <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
          </label>
          <label>পাসওয়ার্ড
            <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} required />
          </label>
          {authErr && <div className="msg err">{authErr}</div>}
          <button className="btn" type="submit">লগইন</button>
        </form>
      </>
    );

  return (
    <>
      <h1>নতুন গান যোগ করুন</h1>
      <p className="sub">
        {user.email}{" "}
        <button className="btn ghost" style={{ padding: "4px 10px" }} onClick={() => signOut(getAuthClient())}>
          লগআউট
        </button>
      </p>

      <form className="form" onSubmit={submit}>
        <label>গানের নাম
          <input value={title} onChange={(e) => setTitle(e.target.value)} required />
        </label>
        <label>শিল্পী
          <input value={artist} onChange={(e) => setArtist(e.target.value)} required />
        </label>
        <label>বিবরণ (ঐচ্ছিক)
          <textarea rows={4} value={description} onChange={(e) => setDescription(e.target.value)} />
        </label>
        <label>অডিও ফাইল (mp3 ইত্যাদি)
          <input type="file" accept="audio/*" onChange={(e) => setAudio(e.target.files[0])} required />
        </label>
        <label>কভার ছবি (ঐচ্ছিক)
          <input type="file" accept="image/*" onChange={(e) => setCover(e.target.files[0])} />
        </label>
        {busy && <div className="bar"><div style={{ width: `${progress}%` }} /></div>}
        {status && <div className={`msg ${status.type}`}>{status.text}</div>}
        <button className="btn" type="submit" disabled={busy}>
          {busy ? "আপলোড হচ্ছে..." : "গান যোগ করুন"}
        </button>
      </form>

      <div className="list">
        <h1 style={{ fontSize: 20 }}>যোগ করা গান ({songs.length})</h1>
        {songs.map((s) => (
          <div className="row" key={s.id}>
            <div>{s.title} <small>– {s.artist}</small></div>
            <button className="btn ghost" style={{ padding: "4px 10px" }} onClick={() => remove(s.id)}>
              মুছুন
            </button>
          </div>
        ))}
      </div>
    </>
  );
}
