import { SITE_URL, getSongs } from "@/lib/songs";

export const revalidate = 3600;

export default async function sitemap() {
  const songs = await getSongs(1000);
  return [
    { url: SITE_URL, lastModified: new Date(), changeFrequency: "daily", priority: 1 },
    ...songs.map((s) => ({
      url: `${SITE_URL}/song/${s.id}`,
      lastModified: s.createdAt ? new Date(s.createdAt) : new Date(),
      changeFrequency: "monthly",
      priority: 0.7,
    })),
  ];
}
