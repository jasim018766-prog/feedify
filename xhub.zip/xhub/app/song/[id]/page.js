import { notFound } from "next/navigation";
import { SITE_URL, getSong, optimizeImage } from "@/lib/songs";

export const revalidate = 60;

export async function generateMetadata({ params }) {
  const { id } = await params;
  const song = await getSong(id);
  if (!song) return { title: "গান পাওয়া যায়নি" };

  const title = `${song.title} – ${song.artist}`;
  const description =
    song.description?.slice(0, 160) ||
    `${song.artist}-এর "${song.title}" গানটি xHub-এ শুনুন।`;
  const image = optimizeImage(song.coverUrl, 800);

  return {
    title,
    description,
    alternates: { canonical: `${SITE_URL}/song/${song.id}` },
    openGraph: {
      title,
      description,
      type: "music.song",
      url: `${SITE_URL}/song/${song.id}`,
      images: image ? [image] : [],
    },
  };
}

export default async function SongPage({ params }) {
  const { id } = await params;
  const song = await getSong(id);
  if (!song) notFound();

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "MusicRecording",
    name: song.title,
    byArtist: { "@type": "MusicGroup", name: song.artist },
    url: `${SITE_URL}/song/${song.id}`,
    image: song.coverUrl || undefined,
    audio: song.audioUrl || undefined,
    description: song.description || undefined,
  };

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      />
      <div className="song">
        {song.coverUrl ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img className="big" src={optimizeImage(song.coverUrl, 800)} alt={song.title} />
        ) : (
          <div className="big" />
        )}
        <div>
          <h1>{song.title}</h1>
          <p className="sub">{song.artist}</p>
          <audio controls preload="none" src={song.audioUrl} />
          <a className="btn" href={song.audioUrl} download>
            ডাউনলোড
          </a>
          {song.description && <p className="desc" style={{ marginTop: 20 }}>{song.description}</p>}
        </div>
      </div>
    </>
  );
}
