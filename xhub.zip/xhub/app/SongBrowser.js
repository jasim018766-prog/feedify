"use client";

import { useMemo, useState } from "react";
import Link from "next/link";

export default function SongBrowser({ songs }) {
  const [q, setQ] = useState("");

  const filtered = useMemo(() => {
    const s = q.trim().toLowerCase();
    if (!s) return songs;
    return songs.filter(
      (x) =>
        x.title.toLowerCase().includes(s) || x.artist.toLowerCase().includes(s)
    );
  }, [q, songs]);

  return (
    <>
      <input
        className="search"
        placeholder="গান বা শিল্পীর নাম খুঁজুন..."
        value={q}
        onChange={(e) => setQ(e.target.value)}
      />
      {filtered.length === 0 ? (
        <p className="empty">কোনো গান পাওয়া যায়নি।</p>
      ) : (
        <div className="grid">
          {filtered.map((s) => (
            <Link key={s.id} href={`/song/${s.id}`} className="card">
              {s.coverUrl ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img className="cover" src={s.coverUrl} alt={s.title} loading="lazy" />
              ) : (
                <div className="cover" />
              )}
              <div className="meta">
                <div className="t">{s.title}</div>
                <div className="a">{s.artist}</div>
              </div>
            </Link>
          ))}
        </div>
      )}
    </>
  );
}
