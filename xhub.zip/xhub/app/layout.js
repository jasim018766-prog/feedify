import "./globals.css";
import Link from "next/link";
import { SITE_URL } from "@/lib/songs";

export const metadata = {
  metadataBase: new URL(SITE_URL),
  title: {
    default: "xHub – গান শুনুন ও ডাউনলোড করুন",
    template: "%s | xHub",
  },
  description: "xHub-এ নতুন ও পুরনো বিভিন্ন গান শুনুন। নিয়মিত নতুন গান যোগ হয়।",
  openGraph: {
    siteName: "xHub",
    type: "website",
    locale: "bn_BD",
  },
};

export default function RootLayout({ children }) {
  return (
    <html lang="bn">
      <body>
        <header className="site">
          <div className="wrap">
            <Link href="/" className="logo">
              x<span>Hub</span>
            </Link>
          </div>
        </header>
        <main>
          <div className="wrap">{children}</div>
        </main>
        <footer>© {new Date().getFullYear()} xHub</footer>
      </body>
    </html>
  );
}
