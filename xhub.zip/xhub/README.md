# xHub – গানের সাইট (Next.js + Firebase + Cloudinary + Vercel)

## ১. Firebase
1. console.firebase.google.com → নতুন প্রজেক্ট → **Firestore Database** চালু করুন (Production mode)।
2. **Authentication → Sign-in method → Email/Password** চালু করুন। তারপর Users ট্যাবে নিজের অ্যাডমিন ইমেইল+পাসওয়ার্ড দিয়ে একটা ইউজার বানান।
3. **Firestore → Rules**-এ `firestore.rules` ফাইলের লেখা বসান (`YOUR_ADMIN_EMAIL` বদলে আপনার ইমেইল দিন) → Publish।
4. Project settings → Your apps → **Web (`</>`)** অ্যাপ যোগ করুন। যে config দেখাবে, তার ভ্যালুগুলো `.env.local`-এ বসাবেন।
5. Firestore → Indexes লাগবে না (শুধু `createdAt` দিয়ে সাজানো হয়)।

## ২. Cloudinary
1. Dashboard থেকে **Cloud name** নিন।
2. Settings → Upload → **Upload presets → Add**: Signing Mode = **Unsigned**, নাম দিন (যেমন `xhub_unsigned`)। Save।
3. এই দুটো `.env.local`-এ বসান।

## ৩. লোকালি চালানো
```bash
cp .env.example .env.local   # ভ্যালু বসান
npm install
npm run dev                  # http://localhost:3000
```
গান যোগ করতে `http://localhost:3000/admin`-এ লগইন করুন।

## ৪. Vercel-এ ডিপ্লয়
1. কোড GitHub রিপোজিটরিতে পুশ করুন।
2. vercel.com → Add New Project → রিপো ইমপোর্ট।
3. **Environment Variables**-এ `.env.example`-এর সব নাম ও ভ্যালু দিন (`NEXT_PUBLIC_SITE_URL` = আপনার আসল ডোমেইন, যেমন `https://xhub.com`)।
4. Deploy।

## ৫. ডোমেইন সংযোগ
Vercel → Project → Settings → Domains → ডোমেইন যোগ করুন। Vercel যে A / CNAME রেকর্ড দেখাবে সেটা আপনার ডোমেইন রেজিস্ট্রারের DNS সেটিংসে বসান।

## ৬. Google সার্চের জন্য
1. search.google.com/search-console → ডোমেইন যোগ করে ভেরিফাই করুন।
2. Sitemaps-এ `sitemap.xml` সাবমিট করুন (সাইট নিজেই বানায়: `/sitemap.xml`)।
3. নিয়মিত গান যোগ করুন এবং প্রতিটি গানের বিবরণে কিছু লেখা দিন, এতে সার্চে আসার সুযোগ বাড়ে।
